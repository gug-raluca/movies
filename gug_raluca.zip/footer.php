</body>
<div class="footer"> 
<?php echo date('d.m.Y'); ?>
 &copy;, Toate drepturile rezervate

</html>
</div>